<div class="col-sm-2">
  <div class="sidebar-nav">
    <div class="navbar navbar-custom" role="navigation">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-navbar-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <span class="visible-xs navbar-brand"><i class="glyphicon glyphicon-home"></i> Beranda</span>
      </div>
      <div class="navbar-collapse collapse sidebar-navbar-collapse">
        <ul class="nav navbar-nav">
          <li><a href="index.php"><span class="glyphicon glyphicon-home"></span> BERANDA</a></li>
          <li><a href="?page=lap-pelanggaran"><span class="glyphicon glyphicon-file"></span> LAPORAN PELANGGARAN</a></li>
          <li><a href="#"><span class="glyphicon glyphicon-file"></span> IKP</a></li>
          <li><a href="#"><span class="glyphicon glyphicon-file"></span> LAPORAN MINGGUAN</a></li>
          <li><a target="_blank" href="http://www.taufiqoey.com/kinerja"><span class="glyphicon glyphicon-file"></span> LAPORAN KINERJA</a></li>
          <li><a href="#"><span class="glyphicon glyphicon-file"></span> LAPORAN PENGAWAS PEMILU</a></li>
        </ul>
      </div><!--/.nav-collapse -->
    </div>
  </div>
</div>
