<b class="page-header">
INDEKS KERAWANAN PILKADA
</b>
  <div id="ikp-data" style="width:60%"></div>
    <script type="text/javascript">
    $(function () {
      $('#ikp-data').highcharts({
          title: {
              text: 'Contoh Tampilan IKP',
              x: -20 //center
          },
          subtitle: {
              text: 'Bawaslu',
              x: -20
          },
          xAxis: {
              categories: ['Kab 1', 'Kab 2', 'Kab 3', 'Kab 4', 'Kab 5', 'Kab 6', 'Kab 7', 'Kab 8']
          },
          yAxis: {
              title: {
                  text: 'Jumlah IKP'
              },
              plotLines: [{
                  value: 0,
                  width: 1,
                  color: '#808080'
              }]
          },
          tooltip: {
              valueSuffix: ''
          },
          legend: {
              layout: 'vertical',
              align: 'right',
              verticalAlign: 'middle',
              borderWidth: 0
          },
          series: [{
              name: 'Akses Pengawasan',
              data: [7, 6, 9, 14, 8]
          }, {
              name: 'Kondisi Keamanan',
              data: [0, 1, 5, 11, 9]
          }, {
              name: 'Partisipasi Masyarakat',
              data: [1, 2, 4, 3, 4]
          }, {
              name: 'Politik Uang',
              data: [3, 4, 5, 8, 7]
          }]
      });
    });
    </script>

Untuk detail tentang Indeks Kerawanan Pemilu silahkan klik infoweb IKP Bawaslu disini

<br><br>


<b class="page-header">
PASANGAN CALON
</b>
<div class="table-responsive">
<table class="table" style="width:100%;">
    <tr>
        <td><a href="index.php"><img class="img-responsive" src="assets/img/foto.gif" style="width:80px;" /></td>
        <td>
            <table style="font-size:10px;">
                <tr>
                    <td>Calon</td>
                    <td>&nbsp &nbsp</td>
                    <td>Bupati</td>
                </tr>
                <tr>
                    <td>Nama</td>
                    <td></td>
                    <td>Nama Bupati</td>
                </tr>
                <tr>
                    <td>TTL</td>
                    <td></td>
                    <td>TTL Bupati</td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td></td>
                    <td>Perempuan / Laki-laki</td>
                </tr>
                <tr>
                    <td>Pekerjaan</td>
                    <td></td>
                    <td>Wakil Bupati</td>
                </tr>
                <tr>
                    <td>Petahana</td>
                    <td></td>
                    <td>Ya</td>
                </tr>
                <tr>
                    <td>Pengusung</td>
                    <td></td>
                    <td>Partai</td>
                </tr>
                <tr>
                    <td>Nama Partai</td>
                    <td></td>
                    <td>Golkar / PDI / dsb</td>
                </tr>
            </table>
        </td>
        <td><a href="index.php"><img class="img-responsive" src="assets/img/foto.gif" style="width:80px;" /></td>
        <td>
            <table style="font-size:10px;">
                <tr>
                    <td>Calon</td>
                    <td>&nbsp &nbsp</td>
                    <td>Bupati</td>
                </tr>
                <tr>
                    <td>Nama</td>
                    <td></td>
                    <td>Nama Bupati</td>
                </tr>
                <tr>
                    <td>TTL</td>
                    <td></td>
                    <td>TTL Bupati</td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td></td>
                    <td>Perempuan / Laki-laki</td>
                </tr>
                <tr>
                    <td>Pekerjaan</td>
                    <td></td>
                    <td>Wakil Bupati</td>
                </tr>
                <tr>
                    <td>Petahana</td>
                    <td></td>
                    <td>Ya</td>
                </tr>
                <tr>
                    <td>Pengusung</td>
                    <td></td>
                    <td>Partai</td>
                </tr>
                <tr>
                    <td>Nama Partai</td>
                    <td></td>
                    <td>Golkar / PDI / dsb</td>
                </tr>
            </table>
          </td>
    </tr>
    <tr>
        <td><a href="index.php"><img class="img-responsive" src="assets/img/foto.gif" style="width:80px;" /></td>
        <td>
            <table style="font-size:10px;">
                <tr>
                    <td>Calon</td>
                    <td>&nbsp &nbsp</td>
                    <td>Bupati</td>
                </tr>
                <tr>
                    <td>Nama</td>
                    <td></td>
                    <td>Nama Bupati</td>
                </tr>
                <tr>
                    <td>TTL</td>
                    <td></td>
                    <td>TTL Bupati</td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td></td>
                    <td>Perempuan / Laki-laki</td>
                </tr>
                <tr>
                    <td>Pekerjaan</td>
                    <td></td>
                    <td>Wakil Bupati</td>
                </tr>
                <tr>
                    <td>Petahana</td>
                    <td></td>
                    <td>Ya</td>
                </tr>
                <tr>
                    <td>Pengusung</td>
                    <td></td>
                    <td>Partai</td>
                </tr>
                <tr>
                    <td>Nama Partai</td>
                    <td></td>
                    <td>Golkar / PDI / dsb</td>
                </tr>
            </table>
        </td>
        <td><a href="index.php"><img class="img-responsive" src="assets/img/foto.gif" style="width:80px;" /></td>
        <td>
            <table style="font-size:10px;">
                <tr>
                    <td>Calon</td>
                    <td>&nbsp &nbsp</td>
                    <td>Bupati</td>
                </tr>
                <tr>
                    <td>Nama</td>
                    <td></td>
                    <td>Nama Bupati</td>
                </tr>
                <tr>
                    <td>TTL</td>
                    <td></td>
                    <td>TTL Bupati</td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td></td>
                    <td>Perempuan / Laki-laki</td>
                </tr>
                <tr>
                    <td>Pekerjaan</td>
                    <td></td>
                    <td>Wakil Bupati</td>
                </tr>
                <tr>
                    <td>Petahana</td>
                    <td></td>
                    <td>Ya</td>
                </tr>
                <tr>
                    <td>Pengusung</td>
                    <td></td>
                    <td>Partai</td>
                </tr>
                <tr>
                    <td>Nama Partai</td>
                    <td></td>
                    <td>Golkar / PDI / dsb</td>
                </tr>
            </table>
          </td>
    </tr>
    <tr>
        <td><a href="index.php"><img class="img-responsive" src="assets/img/foto.gif" style="width:80px;" /></td>
        <td>
            <table style="font-size:10px;">
                <tr>
                    <td>Calon</td>
                    <td>&nbsp &nbsp</td>
                    <td>Bupati</td>
                </tr>
                <tr>
                    <td>Nama</td>
                    <td></td>
                    <td>Nama Bupati</td>
                </tr>
                <tr>
                    <td>TTL</td>
                    <td></td>
                    <td>TTL Bupati</td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td></td>
                    <td>Perempuan / Laki-laki</td>
                </tr>
                <tr>
                    <td>Pekerjaan</td>
                    <td></td>
                    <td>Wakil Bupati</td>
                </tr>
                <tr>
                    <td>Petahana</td>
                    <td></td>
                    <td>Ya</td>
                </tr>
                <tr>
                    <td>Pengusung</td>
                    <td></td>
                    <td>Partai</td>
                </tr>
                <tr>
                    <td>Nama Partai</td>
                    <td></td>
                    <td>Golkar / PDI / dsb</td>
                </tr>
            </table>
        </td>
        <td><a href="index.php"><img class="img-responsive" src="assets/img/foto.gif" style="width:80px;" /></td>
        <td>
            <table style="font-size:10px;">
                <tr>
                    <td>Calon</td>
                    <td>&nbsp &nbsp</td>
                    <td>Bupati</td>
                </tr>
                <tr>
                    <td>Nama</td>
                    <td></td>
                    <td>Nama Bupati</td>
                </tr>
                <tr>
                    <td>TTL</td>
                    <td></td>
                    <td>TTL Bupati</td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td></td>
                    <td>Perempuan / Laki-laki</td>
                </tr>
                <tr>
                    <td>Pekerjaan</td>
                    <td></td>
                    <td>Wakil Bupati</td>
                </tr>
                <tr>
                    <td>Petahana</td>
                    <td></td>
                    <td>Ya</td>
                </tr>
                <tr>
                    <td>Pengusung</td>
                    <td></td>
                    <td>Partai</td>
                </tr>
                <tr>
                    <td>Nama Partai</td>
                    <td></td>
                    <td>Golkar / PDI / dsb</td>
                </tr>
            </table>
          </td>
    </tr>
    <tr>
        <td><a href="index.php"><img class="img-responsive" src="assets/img/foto.gif" style="width:80px;" /></td>
        <td>
            <table style="font-size:10px;">
                <tr>
                    <td>Calon</td>
                    <td>&nbsp &nbsp</td>
                    <td>Bupati</td>
                </tr>
                <tr>
                    <td>Nama</td>
                    <td></td>
                    <td>Nama Bupati</td>
                </tr>
                <tr>
                    <td>TTL</td>
                    <td></td>
                    <td>TTL Bupati</td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td></td>
                    <td>Perempuan / Laki-laki</td>
                </tr>
                <tr>
                    <td>Pekerjaan</td>
                    <td></td>
                    <td>Wakil Bupati</td>
                </tr>
                <tr>
                    <td>Petahana</td>
                    <td></td>
                    <td>Ya</td>
                </tr>
                <tr>
                    <td>Pengusung</td>
                    <td></td>
                    <td>Partai</td>
                </tr>
                <tr>
                    <td>Nama Partai</td>
                    <td></td>
                    <td>Golkar / PDI / dsb</td>
                </tr>
            </table>
        </td>
        <td><a href="index.php"><img class="img-responsive" src="assets/img/foto.gif" style="width:80px;" /></td>
        <td>
            <table style="font-size:10px;">
                <tr>
                    <td>Calon</td>
                    <td>&nbsp &nbsp</td>
                    <td>Bupati</td>
                </tr>
                <tr>
                    <td>Nama</td>
                    <td></td>
                    <td>Nama Bupati</td>
                </tr>
                <tr>
                    <td>TTL</td>
                    <td></td>
                    <td>TTL Bupati</td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td></td>
                    <td>Perempuan / Laki-laki</td>
                </tr>
                <tr>
                    <td>Pekerjaan</td>
                    <td></td>
                    <td>Wakil Bupati</td>
                </tr>
                <tr>
                    <td>Petahana</td>
                    <td></td>
                    <td>Ya</td>
                </tr>
                <tr>
                    <td>Pengusung</td>
                    <td></td>
                    <td>Partai</td>
                </tr>
                <tr>
                    <td>Nama Partai</td>
                    <td></td>
                    <td>Golkar / PDI / dsb</td>
                </tr>
            </table>
          </td>
    </tr>
</table>
</div>

<br><br>

<b class="page-header">
DAFTAR PEMILIH
</b>
  <div id="daftar-pemilih" style="width:60%"></div>
    <script type="text/javascript">
    $(function () {
        $('#daftar-pemilih').highcharts({
            chart: {
                type: 'column'
            },
            title: {
                text: 'DPT'
            },
            subtitle: {
                text: 'Nama Provinsi'
            },
            xAxis: {
                categories: [
                    'Kota 1',
                    'kota 2',
                    'Kota3',
                    'Kota 4',
                    'Kota 5',
                    'Kota 6',
                    'Kota 7',
                    'Kota 8',
                    'Kota 9',
                    'Kota 10',
                    'Kota 11',
                    'Kota 12'
                ],
                crosshair: true
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            tooltip: {
                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                    '<td style="padding:0"><b>{point.y:.1f} Jiwa</b></td></tr>',
                footerFormat: '</table>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
            series: [{
                name: 'Jumlah Penduduk',
                color: '#ccc',
                data: [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4]

            }, {
                name: 'Jumlah DPT',
                data: [83.6, 0, 98.5, 93.4, 106.0, 84.5, 105.0, 104.3, 91.2, 83.5, 106.6, 92.3]

            }]
        });
    });
    </script>
    <div class="well well-sm">
      <small>JUMLAH</small> <b class="pull-right">67</b>
    </div>

<br><br>

<b class="page-header">
Ditribusi Logistik
</b>
<br><br>
<ol>
    <li>Surat Suara</li>
    <li>Tinta</li>
    <li>Formulir</li>
    <li>Template</li>
    <li>Hologram</li>
    <li>Segel</li>
    <li>Sampul</li>
    <li>Kotak Dan Bilik Suara</li>
</ol>

<br><br>

<b class="page-header">
Laporan Pelanggran
</b>
  <div id="laporan-pelanggaran" style="width:60%"></div>
    <script type="text/javascript">
    $(function () {
      $('#laporan-pelanggaran').highcharts({
      		chart: {
      				type: 'column'
      		},
      		title: {
      				text: 'Jumlah Pelanggaran Untuk Provinsi'
      		},
      		subtitle: {
      				text: 'Sistem Pengawasan Pemilu'
      		},
      		xAxis: {
      				type: 'category',
      				labels: {
      						rotation: -15,
      						style: {
      								fontSize: '13px',
      								fontFamily: 'Verdana, sans-serif'
      						}
      				}
      		},
      		yAxis: {
      				min: 0,
      				title: {
      						text: 'Jumlah Pelanggaran'
      				}
      		},
      		legend: {
      				enabled: false
      		},
      		tooltip: {
      				pointFormat: 'Jumlah Pelanggaran: <b>{point.y:.1f}</b>'
      		},
      		series: [{
      				name: 'Population',
      				data: [
      								['Pelanggaran 1', 4],
                      ['Pelanggaran 2', 6],
                      ['Pelanggaran 3', 2],
                      ['Pelanggaran 4', 1],
      				],
      				dataLabels: {
      						enabled: true,
      						rotation: -90,
      						color: '#FFFFFF',
      						align: 'right',
      						format: '{point.y:.1f}', // one decimal
      						y: 10, // 10 pixels down from the top
      						style: {
      								fontSize: '13px',
      								fontFamily: 'Verdana, sans-serif'
      						}
      				}
      		}]
      });
    });
    </script>
