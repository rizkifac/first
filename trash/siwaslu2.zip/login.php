<?php
session_start();
require("assets/include/koneksi.php");
if (isset($_POST['login'])){
  $UserName = htmlentities($_POST['username']);
  $Password = htmlentities($_POST['password']).$salt;
  $Password = sha1($Password);
  $qry = $conn->query("SELECT * FROM erp_user where username='$UserName' AND password='$Password' LIMIT 1") or die (mysql_error());
  $data=$qry->fetch_array();
  if ($UserName==!$data['username'] && $Password==!$data['password'] ) {
    echo "<script>alert('Gagal Masuk, Cek kembali User Name dan Password Anda');</script>";
  }
  elseif ($UserName==$data['username'] && $Password==!$data['password']) {
    echo "<script>alert('Gagal Masuk, Cek kembali User Name dan Password Anda');</script>";
  }
  elseif ($UserName==!$data['username'] && $Password==$data['password']) {
    echo "<script>alert('Gagal Masuk, Cek kembali User Name dan Password Anda');</script>";
  }
  elseif ($UserName==$data['username'] && $Password==$data['password']) {
    // if($data['level'] == 1){
      $_SESSION['id'] = $data['id'];
      echo "<script>document.location.href='admin/index.php';</script>";
    // } else {
    //   echo "<script>alert('BELUM ADA HALAMAN BAGIAN SATKER');</script>";
    // }
  } else {
    echo "<script>alert('Gagal Masuk, Cek kembali User Name dan Password Anda');</script>";
    exit();
  }
}
?>

<form action="#" method="post" id="form-login" class="navbar-form navbar-right" role="form" style="margin-top:20px; display:none;">
  <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
      <input type="text" autofocus required class="form-control" name="username" value="" placeholder="Username" size="10">
  </div>
  <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input type="password" required class="form-control" name="password" value="" placeholder="Password" size="10">
  </div>
  <button type="submit" class="btn btn-primary" name="login">Login</button>
</form>
