<?php
require("../assets/include/koneksi.php");
  if(!isset($_GET['id'])){
    echo "<div class='alert alert-warning'><h3 class='text-center'>Something's Wrong</h3></div>";
    exit();
  }
?>
<?php
$q_berita = $conn->query("SELECT * FROM q_berita WHERE id='$_GET[id]'");
$d_berita = $q_berita->fetch_assoc();
?>
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><?php echo $d_berita['judul']; ?></h3>
  </div>
  <div class="panel-body">
    <?php
      echo $d_berita['isi'];
      echo "<br><br>";
      echo "<span class='text-info'>publish : <small> " . $d_berita['tanggal'] . "</small></span>";
    ?>
  </div>
  <div class="panel-footer">
    <a href="?page=berita-data" class="btn btn-default btn-sm">Kembali</a>
  </div>
</div>
