
<?php
	session_start();
	session_destroy();
?>
<script language="javascript">document.location.href='../index.php';</script>
