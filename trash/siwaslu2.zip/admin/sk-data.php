<div class="well well-sm text-center"><h4>Data Satuan Kerja</h4></div>
<table class="table table-striped flex">
  <thead>
    <tr>
      <th>No</th>
      <th>Satuan Kerja</th>
      <th>User</th>
      <th>Aksi</th>
    </tr>
  </thead>

  <tbody>
<?php
$no = 1;
require "../assets/include/koneksi.php";
$q_satker = $conn->query("SELECT * FROM q_satker");
while($d_satker=$q_satker->fetch_assoc()){
?>
    <tr>
      <td><?php echo $no++ ?></td>
      <td><?php echo $d_satker['satker']; ?></td>
      <td>
        <?php
        $q_user = $conn->query("SELECT * FROM q_user WHERE id_satker='$d_satker[id]'");
        $d_user = $q_user->fetch_assoc();
        $j_user = mysqli_num_rows($q_user);
          if($j_user){
            echo "<a href='?page=user-profil&id=".$d_user['id']."' class='btn btn-sm btn-primary'>Lihat User</a>";
          } else {
            echo "Belum Ada User ";
            echo "<a href='?page=user-tambah&id=".$d_satker['id']."' class='btn btn-sm btn-warning'>Tambah Disini</a>";
          }
        ?>
      </td>
      <td>hapus</td>
    </tr>
<?php
}
?>

  </tbody>
</table>
