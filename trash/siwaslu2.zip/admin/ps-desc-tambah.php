<?php
require("../assets/include/koneksi.php");
  if(!isset($_GET['id'])){
    echo "<div class='alert alert-warning'><h3 class='text-center'>Something's Wrong</h3></div>";
    exit();
  }
$q_ps = $conn->query("SELECT * FROM q_ps WHERE id='$_GET[id]'");
$d_ps = $q_ps->fetch_assoc();
?>

<div class="well well-sm text-center"><h4>Tambah Deskripsi Peta Strategi</h4></div>
<div id="hasil"/></div>

<div class="col-md-12">
  <div class="panel panel-default">
    <div class="panel-heading">
      <p><i class="fa fa-lock"></i> Tambah Deskripsi Peta Strategi</p>
    </div>
    <div class="panel-body">
      <form id="desc-tambah" class="form-horizontal" method="POST" action="ps-proses.php">
        <div class="col-sm-6">
          <div class="form-group form-group-sm">
            <label class="col-sm-4 col-md-4 control-label"> Peta Strategi </label>
            <div class="col-sm-8 col-md-8">
            <input type="text" class="form-control" name="nama_ps" disabled value="<?php echo $d_ps['nama']; ?>" title="Peta Strategi" required/>
            <input type="hidden" value="<?php echo $_GET['id']; ?>" name="ps" />
            <input type="hidden" value="tambah-desc" name="respon" />
            </div>
          </div><!-- form-group -->

          <div class="form-group form-group-sm">
            <label class="col-sm-4 col-md-4 control-label">  Isi Deskripsi </label>
            <div class="col-sm-8 col-md-8">
            <textarea name="isi" class="form-control" required title="Isi Deskripsi"></textarea>
            </div>
          </div><!-- form-group -->

          <div class="form-group form-group-sm">
            <label class="col-sm-4 col-md-4 control-label"> </label>
            <div class="col-sm-8 col-md-8">
            <button class="btn btn-theme03" type="submit" name="submit" style="float:left;"><i class="fa fa-save"></i> Simpan</button>
            <a href="?page=ps-data" class="btn btn-theme03" style="float:left;"> Kembali</a>
            </div>
          </div><!-- form-group -->
        </div><!-- col-sm-6 -->
      </form>
    </div><!-- panel body -->
  </div> <!-- panel -->
</div> <!-- col md 12 -->


<script type="text/javascript">
<!--
	$('#desc-tambah').submit(function(){
		$.ajax({
			type: 'POST',
			url: $(this).attr('action'),
			data: $(this).serialize(),
			beforeSend: function() {
				$('#hasil').html('<div class="text-center"><img src="../assets/img/loading.gif" alt="loading..." width="10%" /></div>');
			},
			success: function(data) {
        $('#hasil').hide();
        $('#hasil').html(data).show('slow');
				}
		});
		return false;
	});
-->
</script>
