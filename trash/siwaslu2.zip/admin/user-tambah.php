<div class="well well-sm text-center"><h4>Tambah Admin</h4></div>
<div id="hasil"/></div>

<div class="col-md-12">
  <div class="panel panel-default">
    <div class="panel-heading">
      <p><i class="fa fa-lock"></i> Tambah Admin</p>
    </div>
    <div class="panel-body">
      <form id="user-tambah" class="form-horizontal" method="POST" action="user-proses.php">
        <div class="col-sm-6">
          <div class="form-group form-group-sm">
            <label class="col-sm-4 col-md-4 control-label"> Nama </label>
            <div class="col-sm-8 col-md-8">
            <input type="text" class="form-control" name="nama" value="" title="Nama User" required/>
            <input type="hidden" value="user-tambah" name="respon" />
            </div>
          </div><!-- form-group -->

          <div class="form-group form-group-sm">
            <label class="col-sm-4 col-md-4 control-label"> Email </label>
            <div class="col-sm-8 col-md-8">
            <input type="email" class="form-control" name="email" value="" title="Email User" required/>
            </div>
          </div><!-- form-group -->

          <div class="form-group form-group-sm">
            <label class="col-sm-4 col-md-4 control-label"> Admin Untuk </label>
            <div class="col-sm-8 col-md-8">
              <select class="form-control" name="level">
                <option value="1">Admin Utama</option>
                <option value="2">Admin Organisasi , SDM dan DATIN</option>
                <option value="3">Admin Sosialisasi, HUMAS dan HUBAL</option>
                <option value="4">Admin Hukum dan Penanganan Pelanggaran</option>
                <option value="5">Admin Pengawasan</option>
              </select>
            </div>
          </div><!-- form-group -->


          <div class="form-group form-group-sm">
            <label class="col-sm-4 col-md-4 control-label"> Username </label>
            <div class="col-sm-8 col-md-8">
            <input type="text" class="form-control" name="username" value="" title="Username Admin" required/>
            </div>
          </div><!-- form-group -->

          <div class="form-group form-group-sm">
            <label class="col-sm-4 col-md-4 control-label"> Password </label>
            <div class="col-sm-8 col-md-8">
            <input type="password" class="form-control" name="password" value="" title="Password Admin" required/>
            </div>
          </div><!-- form-group -->

          <div class="form-group form-group-sm">
            <label class="col-sm-4 col-md-4 control-label"> Konfirmasi Password </label>
            <div class="col-sm-8 col-md-8">
            <input type="password" class="form-control" name="repassword" value="" title="Ulangi Password Admin" required/>
            </div>
          </div><!-- form-group -->


          <div class="form-group form-group-sm">
            <label class="col-sm-4 col-md-4 control-label"> </label>
            <div class="col-sm-8 col-md-8">
            <button class="btn btn-theme03" type="submit" name="submit" style="float:left;"><i class="fa fa-save"></i> Simpan</button>
            <a href="?page=user-data" class="btn btn-theme03" style="float:left;"> Kembali</a>
            </div>
          </div><!-- form-group -->
        </div><!-- col-sm-6 -->
      </form>
    </div><!-- panel body -->
  </div> <!-- panel -->
</div> <!-- col md 12 -->


<script type="text/javascript">
<!--
	$('#user-tambah').submit(function(){
		$.ajax({
			type: 'POST',
			url: $(this).attr('action'),
			data: $(this).serialize(),
			beforeSend: function() {
				$('#hasil').html('<div class="text-center"><img src="../assets/img/loading.gif" alt="loading..." width="10%" /></div>');
			},
			success: function(data) {
        $('#hasil').hide();
        $('#hasil').html(data).show('slow');
				}
		});
		return false;
	});
-->
</script>
