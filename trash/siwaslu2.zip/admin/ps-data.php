<div class="well well-sm text-center"><h4>Data Peta Strategi</h4></div>
<table class="table table-striped flex">
  <thead>
    <tr>
      <th>No</th>
      <th>Nama</th>
      <th>Data Deskripsi</th>
    </tr>
  </thead>

  <tbody>
<?php
$no = 1;
require "../assets/include/koneksi.php";
$qry = "SELECT * FROM q_ps";
$res = $conn->query($qry);
while($data=$res->fetch_assoc()){
?>
    <tr>
      <td><?php echo $no++ ?></td>
      <td><?php echo $data['nama']; ?></td>
      <td>
        <a href="?page=ps-desc&id=<?php echo $data['id'] ?>" class="btn btn-sm btn-primary">Lihat</a>
        <a href="?page=ps-desc-tambah&id=<?php echo $data['id'] ?>" class="btn btn-sm btn-primary">Tambah</a>
      </td>
    </tr>
<?php
}
?>

  </tbody>
</table>
