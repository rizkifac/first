<?php
include"../assets/include/koneksi.php";
$respon = mysql_real_escape_string($_POST['respon']);

switch ($respon){

	case"user-tambah";
		$nama = mysql_escape_string($_POST['nama']);
		$email = mysql_escape_string($_POST['email']);
		$level = mysql_escape_string($_POST['level']);
		$username = mysql_escape_string($_POST['username']);
		$password = mysql_escape_string($_POST['password']);
		$repassword = mysql_escape_string($_POST['repassword']);

		if(empty($nama) || empty($email) || empty($level) || empty($username) || empty($password) || empty($repassword)){
			echo "<div class='alert alert-warning'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
				<strong>UPS!</strong> JANGAN ADA DATA YANG KOSONG.
				</div>";
		} elseif ($password != $repassword) {
			echo "<div class='alert alert-warning'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
				<strong>UPS!</strong> Konfirmasi Password Tidak Sesuai.
				</div>";
		} else {
			$password = $_POST['password'].$salt;
		  $password = sha1($password);
			$q_user_tambah = $conn->query("INSERT INTO erp_user VALUES('','$nama','$email','$username','$password','$level',NOW())");
			if($q_user_tambah){
				echo "<div class='alert alert-success'>
					<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
					<strong>SUCCESS !</strong> Data Berhasil Disimpan.
					</div>";
			} else {
				echo "<div class='alert alert-danger'>
					<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
					<strong>ERROR!</strong> Data Gagal Disimpan.
					</div>";
			}
		}
	break;

	case"user-hapus";
	 $id = mysql_escape_string($_POST['id']);
	 $q_user_hapus = $conn->query("DELETE FROM erp_user WHERE id='$id'");
	 if($q_user_hapus){
		 echo "<div class='alert alert-success'>
			 <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
			 <strong>SUCCESS !</strong> Data Berhasil Dihapus.
			 </div>";
	 } else {
		 echo "<div class='alert alert-danger'>
			 <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
			 <strong>ERROR!</strong> Data Gagal Dihapus.
			 </div>";
	 }
	break;

case"none";
 /* CODE DISINI */
break;


}
?>
