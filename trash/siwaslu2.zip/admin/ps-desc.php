<?php
  $id = $_GET['id'];
?>

<div class="well well-sm text-center"><h4>Data Deskripsi Peta Strategi</h4></div>
<div id="hasil"/></div>
<table class="table table-striped flex">
  <thead>
    <tr>
      <th>No</th>
      <th>Peta Strategi</th>
      <th>Isi Deskripsi</th>
      <th>Aksi</th>
    </tr>
  </thead>

  <tbody>
<?php
$no = 1;
require "../assets/include/koneksi.php";
$q_desc = "SELECT * FROM q_ps_desc WHERE id_ps='$id'";
$h_desc = $conn->query($q_desc);
while($d_desc=$h_desc->fetch_assoc()){
?>
    <tr id="tr_<?php echo $d_desc['id']; ?>">
      <td><?php echo $no++ ?></td>
      <td>
        <?php
        $q_ps = $conn->query("SELECT * FROM q_ps WHERE id='$id'");
        while($d_ps = $q_ps->fetch_assoc()){
          echo $d_ps['nama'];
        }
        ?>
      </td>
      <td><?php echo $d_desc['isi']; ?></td>
      <td><button value="<?php echo $d_desc['id']; ?>" name="hapus-desc" class="btn btn-sm btn-primary hapus_desc">Hapus</button></td>
    </tr>
<?php
}
?>
  </tbody>
</table>
<a href="?page=ps-data" class="btn btn-default" style="float:left;"> Kembali</a>

<script type="text/javascript">
  $('.hapus_desc').click(function(){
    tanya=confirm("Apakah anda yakin akan menghapus data ini?")
    if (tanya !="0")
    {
      var id_desc = $(this).val();
      var respon = $(this).attr('name');
      var semua = 'id=' + id_desc + '&respon=' + respon;
      $.ajax({
        type: 'POST',
        url: 'ps-proses.php',
        data: semua,
        beforeSend: function() {
          $('#hasil').html('<div class="text-center"><img src="../assets/img/loading.gif" alt="loading..." width="10%" /></div>');
          $('#tr_' + id_desc).css('background','#FF9FA9');
        },
        success: function(data) {
          $('#hasil').hide();
          $('#hasil').html(data);
          $('#hasil').show('slow');
          $('#tr_' + id_desc).fadeOut('slow');
          }
      });
      return false;
    }
  });
</script>
