<?php
include"../assets/include/koneksi.php";
$respon = mysql_real_escape_string($_POST['respon']);

switch ($respon){

	case"berita-tambah";
		$judul = mysql_escape_string($_POST['judul']);
		$isi = mysql_escape_string($_POST['isi']);

		if(empty($judul) || empty($isi)){
			echo "<div class='alert alert-warning'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
				<strong>UPS!</strong> JANGAN ADA DATA YANG KOSONG.
				</div>";
		} else {
			$q_berita_tambah = $conn->query("INSERT INTO q_berita VALUES('','$judul','$isi',NOW())");
			if($q_berita_tambah){
				echo "<div class='alert alert-success'>
					<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
					<strong>SUCCESS !</strong> Data Berhasil Disimpan.
					</div>";
			} else {
				echo "<div class='alert alert-danger'>
					<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
					<strong>ERROR!</strong> Data Gagal Disimpan.
					</div>";
			}
		}
	break;

	case"berita-hapus";
	 $id = mysql_escape_string($_POST['id']);
	 $q_berita_hapus = $conn->query("DELETE FROM q_berita WHERE id='$id'");
	 if($q_berita_hapus){
		 echo "<div class='alert alert-success'>
			 <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
			 <strong>SUCCESS !</strong> Data Berhasil Dihapus.
			 </div>";
	 } else {
		 echo "<div class='alert alert-danger'>
			 <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
			 <strong>ERROR!</strong> Data Gagal Dihapus.
			 </div>";
	 }
	break;

case"none";
 /* CODE DISINI */
break;


}
?>
