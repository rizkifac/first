<div class="well well-sm text-center"><h4>Data Berita Kinerja</h4></div>
<div id="hasil"></div>
<a href="?page=berita-tambah" class="btn btn-sm btn-default">Tambah Berita</a><br><br>
<table class="table table-striped flex">
  <thead>
    <tr>
      <th>No</th>
      <th>Judul</th>
      <th>Isi</th>
      <th>Tanggal</th>
      <th>Aksi</th>
    </tr>
  </thead>

  <tbody>
<?php
$no = 1;
require "../assets/include/koneksi.php";
$qry = "SELECT * FROM q_berita order by id desc";
$res = $conn->query($qry);
while($data=$res->fetch_assoc()){
?>
    <tr id="tr_<?php echo $data['id'];?>">
      <td><?php echo $no++ ?></td>
      <td><?php echo $data['judul']; ?></td>
      <td><?php echo substr($data['isi'], 0, 50); ?></td>
      <td><?php echo $data['tanggal']; ?></td>
      <td>
        <a href="?page=berita-lengkap&id=<?php echo $data['id'] ?>" class="btn btn-sm btn-primary">Lihat</a>
        <button value="<?php echo $data['id']; ?>" name="berita-hapus" class="btn btn-sm btn-primary berita-hapus">Hapus</button>
      </td>
    </tr>
<?php
}
?>

  </tbody>
</table>

<script type="text/javascript">
  $('.berita-hapus').click(function(){
    tanya=confirm("Apakah anda yakin akan menghapus data ini?")
    if (tanya !="0")
    {
      var id = $(this).val();
      var respon = $(this).attr('name');
      var semua = 'id=' + id + '&respon=' + respon;
      $.ajax({
        type: 'POST',
        url: 'berita-proses.php',
        data: semua,
        beforeSend: function() {
          $('#hasil').html('<div class="text-center"><img src="../assets/img/loading.gif" alt="loading..." width="10%" /></div>');
          $('#tr_' + id).css('background','#FF9FA9');
        },
        success: function(data) {
          $('#hasil').hide();
          $('#hasil').html(data);
          $('#hasil').show('slow');
          $('#tr_' + id).fadeOut('slow');
          }
      });
      return false;
    }
  });
</script>
