<?php
require("../assets/include/koneksi.php");
  if(!isset($_GET['id'])){
    echo "<div class='alert alert-warning'><h3 class='text-center'>Something's Wrong</h3></div>";
    exit();
  }
?>

<?php
$q_user = $conn->query("SELECT * FROM erp_user WHERE id='$_GET[id]'");
$d_user = $q_user->fetch_assoc();
?>

<div class="well well-sm text-center"><h4>Profile Admin</h4></div>

<div class="col-md-12">
  <div class="panel panel-default">
    <div class="panel-heading">
      <p><i class="fa fa-lock"></i> Data User</p>
    </div>
    <div class="panel-body">
        <div class="col-sm-10">
          <div class="form-group form-group-sm">
            <label class="col-md-3 control-label"> Nama </label>
            <div class="col-md-9">
            <label class="control-label">: <?php echo $d_user['nama']; ?> </label>
            </div>
          </div><!-- form-group -->

          <div class="form-group form-group-sm">
            <label class="col-md-3 control-label"> Email </label>
            <div class="col-md-9">
            <label class="control-label">: <?php echo $d_user['email']; ?> </label>
            </div>
          </div><!-- form-group -->

          <div class="form-group form-group-sm">
            <label class="col-md-3 control-label"> Level Admin </label>
            <div class="col-md-9">
            <?php
            $nama_level="";
            if ($d_user['level']==1){
              $nama_level="Admin Utama";
            } elseif ($d_user['level']==2){
              $nama_level="Admin Organisasi , SDM dan DATIN";
            } elseif ($d_user['level']==3){
              $nama_level="Admin Sosialisasi, HUMAS dan HUBAL";
            } elseif ($d_user['level']==3){
              $nama_level="Admin Hukum dan Penanganan Pelanggaran";
            } else {
              $nama_level="Admin Pengawasan";
            }
            ?>
            <label class="control-label">: <?php echo $nama_level; ?> </label>
            </div>
          </div><!-- form-group -->

          <div class="form-group form-group-sm">
            <label class="col-md-3 control-label"> Username </label>
            <div class="col-md-9">
            <label class="control-label">: <?php echo $d_user['username']; ?> </label>
            </div>
          </div><!-- form-group -->

          <div class="form-group form-group-sm">
            <label class="col-md-3 control-label"> Password <i>(Enkrip)</i> </label>
            <div class="col-md-9">
            <label class="control-label">: <?php echo $d_user['password']; ?> </label>
            </div>
          </div><!-- form-group -->

          <div class="form-group form-group-sm">
            <label class="col-md-3 control-label"> </label>
            <div class="col-md-9">
            <a href="?page=user-data" class="btn btn-default" style="float:left;"> Kembali</a>
            </div>
          </div><!-- form-group -->
        </div><!-- col-sm-6 -->
      </form>
    </div><!-- panel body -->
  </div> <!-- panel -->
</div> <!-- col md 12 -->
