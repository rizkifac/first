
<div class="well well-sm text-center"><h4>Tambah Berita Kinerja</h4></div>
<div id="hasil"/></div>

<div class="col-md-12">
  <div class="panel panel-default">
    <div class="panel-heading">
      <p><i class="fa fa-lock"></i> Tambah Berita Kinerja</p>
    </div>
    <div class="panel-body">
      <form id="berita-tambah" class="form-horizontal" method="POST" action="berita-proses.php">
        <div class="col-sm-6">
          <div class="form-group form-group-sm">
            <label class="col-sm-4 col-md-4 control-label"> Judul </label>
            <div class="col-sm-8 col-md-8">
            <input type="text" class="form-control" name="judul" value="" title="Judul Berita" required/>
            <input type="hidden" value="berita-tambah" name="respon" />
            </div>
          </div><!-- form-group -->

          <div class="form-group form-group-sm">
            <label class="col-sm-4 col-md-4 control-label">  Isi Berita </label>
            <div class="col-sm-8 col-md-8">
            <textarea name="isi" class="form-control" required title="Isi Berita"></textarea>
            </div>
          </div><!-- form-group -->

          <div class="form-group form-group-sm">
            <label class="col-sm-4 col-md-4 control-label"> </label>
            <div class="col-sm-8 col-md-8">
            <button class="btn btn-theme03" type="submit" name="submit" style="float:left;"><i class="fa fa-save"></i> Simpan</button>
            <a href="?page=berita-data" class="btn btn-theme03" style="float:left;"> Kembali</a>
            </div>
          </div><!-- form-group -->
        </div><!-- col-sm-6 -->
      </form>
    </div><!-- panel body -->
  </div> <!-- panel -->
</div> <!-- col md 12 -->


<script type="text/javascript">
<!--
	$('#berita-tambah').submit(function(){
		$.ajax({
			type: 'POST',
			url: $(this).attr('action'),
			data: $(this).serialize(),
			beforeSend: function() {
				$('#hasil').html('<div class="text-center"><img src="../assets/img/loading.gif" alt="loading..." width="10%" /></div>');
			},
			success: function(data) {
        $('#hasil').hide();
        $('#hasil').html(data).show('slow');
				}
		});
		return false;
	});
-->
</script>
